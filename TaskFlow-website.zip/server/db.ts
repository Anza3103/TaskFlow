import mysql, { type Pool, type PoolConnection, type ResultSetHeader } from 'mysql2/promise';

let pool: Pool | undefined;

function databaseConfig() {
  const raw = process.env.DATABASE_URL;
  if (!raw) throw new Error('DATABASE_URL is not configured. TaskFlow cannot start without persistent storage.');
  const url = new URL(raw);
  return {
    host: url.hostname,
    port: Number(url.port || 3306),
    user: decodeURIComponent(url.username),
    password: decodeURIComponent(url.password),
    database: url.pathname.replace(/^\//, ''),
    waitForConnections: true,
    connectionLimit: 10,
    timezone: 'Z' as const,
    dateStrings: true,
    ssl: { rejectUnauthorized: true },
  };
}

export function getPool(): Pool {
  if (!pool) pool = mysql.createPool(databaseConfig());
  return pool;
}

export async function query<T>(sql: string, values: unknown[] = []): Promise<T> {
  const [rows] = await getPool().execute(sql, values as any[]);
  return rows as T;
}

export async function execute(sql: string, values: unknown[] = []): Promise<ResultSetHeader> {
  const [result] = await getPool().execute<ResultSetHeader>(sql, values as any[]);
  return result;
}

export async function withTransaction<T>(work: (connection: PoolConnection) => Promise<T>): Promise<T> {
  const connection = await getPool().getConnection();
  try {
    await connection.beginTransaction();
    const result = await work(connection);
    await connection.commit();
    return result;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
}

export async function initializeDatabase(): Promise<void> {
  const statements = [
    `CREATE TABLE IF NOT EXISTS users (
      id VARCHAR(191) PRIMARY KEY,
      name VARCHAR(160) NOT NULL DEFAULT 'TaskFlow user',
      email VARCHAR(255) NULL,
      timezone VARCHAR(64) NOT NULL DEFAULT 'Asia/Karachi',
      created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      last_login_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3)
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS preferences (
      user_id VARCHAR(191) PRIMARY KEY,
      timezone VARCHAR(64) NOT NULL DEFAULT 'Asia/Karachi',
      work_start_hour TINYINT NOT NULL DEFAULT 9,
      work_end_hour TINYINT NOT NULL DEFAULT 18,
      default_duration_minutes SMALLINT NOT NULL DEFAULT 45,
      break_minutes SMALLINT NOT NULL DEFAULT 10,
      working_days VARCHAR(32) NOT NULL DEFAULT '1,2,3,4,5',
      planning_style VARCHAR(40) NOT NULL DEFAULT 'balanced',
      CONSTRAINT fk_preferences_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS goals (
      id CHAR(36) PRIMARY KEY,
      user_id VARCHAR(191) NOT NULL,
      title VARCHAR(200) NOT NULL,
      description TEXT NOT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'active',
      due_at DATETIME NULL,
      created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      INDEX idx_goals_user_created (user_id, created_at),
      CONSTRAINT fk_goals_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS milestones (
      id CHAR(36) PRIMARY KEY,
      goal_id CHAR(36) NOT NULL,
      title VARCHAR(200) NOT NULL,
      sequence_number INT NOT NULL,
      CONSTRAINT fk_milestones_goal FOREIGN KEY (goal_id) REFERENCES goals(id) ON DELETE CASCADE
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS tasks (
      id CHAR(36) PRIMARY KEY,
      user_id VARCHAR(191) NOT NULL,
      title VARCHAR(240) NOT NULL,
      description TEXT NOT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'pending',
      priority VARCHAR(20) NOT NULL DEFAULT 'medium',
      due_at DATETIME NULL,
      estimated_duration_minutes SMALLINT NOT NULL DEFAULT 45,
      actual_duration_minutes SMALLINT NULL,
      goal_id CHAR(36) NULL,
      milestone_id CHAR(36) NULL,
      parent_task_id CHAR(36) NULL,
      created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      updated_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3) ON UPDATE CURRENT_TIMESTAMP(3),
      completed_at DATETIME NULL,
      INDEX idx_tasks_user_status_due (user_id, status, due_at),
      INDEX idx_tasks_goal (goal_id),
      CONSTRAINT fk_tasks_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      CONSTRAINT fk_tasks_goal FOREIGN KEY (goal_id) REFERENCES goals(id) ON DELETE SET NULL,
      CONSTRAINT fk_tasks_milestone FOREIGN KEY (milestone_id) REFERENCES milestones(id) ON DELETE SET NULL,
      CONSTRAINT fk_tasks_parent FOREIGN KEY (parent_task_id) REFERENCES tasks(id) ON DELETE SET NULL
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS task_dependencies (
      task_id CHAR(36) NOT NULL,
      depends_on_task_id CHAR(36) NOT NULL,
      PRIMARY KEY (task_id, depends_on_task_id),
      CONSTRAINT fk_dependencies_task FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
      CONSTRAINT fk_dependencies_parent FOREIGN KEY (depends_on_task_id) REFERENCES tasks(id) ON DELETE CASCADE
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS scheduled_sessions (
      id CHAR(36) PRIMARY KEY,
      task_id CHAR(36) NOT NULL,
      start_at DATETIME NOT NULL,
      end_at DATETIME NOT NULL,
      notes TEXT NOT NULL,
      created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      INDEX idx_sessions_time (start_at, end_at),
      CONSTRAINT fk_sessions_task FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS conversation_messages (
      id CHAR(36) PRIMARY KEY,
      user_id VARCHAR(191) NOT NULL,
      role VARCHAR(20) NOT NULL,
      content TEXT NOT NULL,
      created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      INDEX idx_messages_user_created (user_id, created_at),
      CONSTRAINT fk_messages_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB`,
    `CREATE TABLE IF NOT EXISTS pending_actions (
      id CHAR(36) PRIMARY KEY,
      user_id VARCHAR(191) NOT NULL,
      action_type VARCHAR(40) NOT NULL,
      payload JSON NOT NULL,
      summary VARCHAR(1000) NOT NULL,
      expires_at DATETIME NOT NULL,
      consumed_at DATETIME NULL,
      created_at DATETIME(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
      INDEX idx_pending_user_expiry (user_id, expires_at),
      CONSTRAINT fk_pending_actions_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB`,
  ];
  for (const statement of statements) await execute(statement);
}

export function toSqlDate(value: string | Date | null | undefined): string | null {
  if (!value) return null;
  const date = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(date.getTime())) throw new Error('Invalid date.');
  return date.toISOString().slice(0, 19).replace('T', ' ');
}

export function toIso(value: unknown): string | null {
  if (!value) return null;
  if (value instanceof Date) return value.toISOString();
  const raw = String(value);
  return new Date(raw.includes('T') ? raw : `${raw.replace(' ', 'T')}Z`).toISOString();
}
