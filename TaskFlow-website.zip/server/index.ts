import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import cookieParser from 'cookie-parser';
import express, { type NextFunction, type Request, type Response } from 'express';
import { ZodError, z } from 'zod';
import { finishLogin, logout, requireUser, startLogin } from './auth.js';
import { initializeDatabase } from './db.js';
import { confirmAssistantAction, runAssistant } from './agent.js';
import { completeTask, createPendingAction, createTask, draftGoalPlan, getAnalytics, getPreferences, getTask, healthCheck, listGoals, listSessions, listTasks, updatePreferences, updateTask, validateGoalPlan } from './taskflow.js';

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const clientDir = path.resolve(__dirname, '../dist/client');

app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());

app.get('/health', async (_req, res) => {
  try { await healthCheck(); res.status(200).json({ status: 'ok', storage: 'connected' }); }
  catch { res.status(503).json({ status: 'unavailable', storage: 'unreachable' }); }
});

app.get('/api/auth/login', startLogin);
app.get('/api/auth/callback', (req, res) => { void finishLogin(req, res); });
app.post('/api/auth/logout', logout);
app.get('/api/auth/me', requireUser, (req, res) => res.json({ authenticated: true, user: req.taskflowUser }));

app.get('/api/bootstrap', requireUser, async (req, res, next) => {
  try {
    const userId = req.taskflowUser!.id;
    const [tasks, goals, sessions, preferences, analytics] = await Promise.all([listTasks(userId), listGoals(userId), listSessions(userId), getPreferences(userId), getAnalytics(userId)]);
    res.json({ user: req.taskflowUser, tasks, goals, sessions, preferences, analytics });
  } catch (error) { next(error); }
});

app.get('/api/tasks', requireUser, async (req, res, next) => {
  try { res.json(await listTasks(req.taskflowUser!.id, { status: typeof req.query.status === 'string' ? req.query.status : undefined, priority: typeof req.query.priority === 'string' ? req.query.priority : undefined, search: typeof req.query.search === 'string' ? req.query.search : undefined, overdue: req.query.overdue === 'true' })); }
  catch (error) { next(error); }
});
app.post('/api/tasks', requireUser, async (req, res, next) => { try { res.status(201).json(await createTask(req.taskflowUser!.id, req.body)); } catch (error) { next(error); } });
app.patch('/api/tasks/:taskId', requireUser, async (req, res, next) => {
  try {
    if (Object.prototype.hasOwnProperty.call(req.body, 'due_at')) {
      const task = await getTask(req.taskflowUser!.id, String(req.params.taskId));
      if (!task) return res.status(404).json({ error: 'NOT_FOUND', message: 'Task not found.' });
      const pendingAction = await createPendingAction(req.taskflowUser!.id, 'move_deadline', { task_id: task.id, due_at: req.body.due_at, expected_updated_at: task.updated_at }, `Move “${task.title}” to ${new Date(req.body.due_at).toLocaleString()}.`);
      return res.status(409).json({ requiresConfirmation: true, pendingAction });
    }
    res.json(await updateTask(req.taskflowUser!.id, String(req.params.taskId), req.body));
  } catch (error) { next(error); }
});
app.post('/api/tasks/:taskId/complete', requireUser, async (req, res, next) => { try { res.json(await completeTask(req.taskflowUser!.id, String(req.params.taskId))); } catch (error) { next(error); } });
app.delete('/api/tasks/:taskId', requireUser, async (req, res, next) => {
  try {
    const task = await getTask(req.taskflowUser!.id, String(req.params.taskId));
    if (!task) return res.status(404).json({ error: 'NOT_FOUND', message: 'Task not found.' });
    const pendingAction = await createPendingAction(req.taskflowUser!.id, 'delete_task', { task_id: task.id, expected_updated_at: task.updated_at }, `Delete “${task.title}” permanently.`);
    return res.status(409).json({ requiresConfirmation: true, pendingAction });
  } catch (error) { next(error); }
});

app.get('/api/goals', requireUser, async (req, res, next) => { try { res.json(await listGoals(req.taskflowUser!.id)); } catch (error) { next(error); } });
app.post('/api/goals/draft', requireUser, (req, res, next) => { try { res.json(draftGoalPlan(req.body)); } catch (error) { next(error); } });
app.post('/api/goals/propose', requireUser, async (req, res, next) => { try { const plan = validateGoalPlan(req.body); const pendingAction = await createPendingAction(req.taskflowUser!.id, 'save_goal_plan', { plan }, `Save “${plan.goal.title}” with ${plan.tasks.length} tasks and dependencies.`); res.json({ pendingAction }); } catch (error) { next(error); } });
app.get('/api/sessions', requireUser, async (req, res, next) => { try { res.json(await listSessions(req.taskflowUser!.id)); } catch (error) { next(error); } });
app.get('/api/analytics', requireUser, async (req, res, next) => { try { res.json(await getAnalytics(req.taskflowUser!.id)); } catch (error) { next(error); } });
app.get('/api/preferences', requireUser, async (req, res, next) => { try { res.json(await getPreferences(req.taskflowUser!.id)); } catch (error) { next(error); } });
app.put('/api/preferences', requireUser, async (req, res, next) => { try { res.json(await updatePreferences(req.taskflowUser!.id, req.body)); } catch (error) { next(error); } });

app.post('/api/assistant', requireUser, async (req, res, next) => { try { const body = z.object({ message: z.string().trim().min(1).max(6000) }).parse(req.body); res.json(await runAssistant(req.taskflowUser!.id, body.message)); } catch (error) { next(error); } });
app.post('/api/assistant/confirm', requireUser, async (req, res, next) => { try { res.json(await confirmAssistantAction(req.taskflowUser!.id, req.body)); } catch (error) { next(error); } });

app.use((error: unknown, _req: Request, res: Response, _next: NextFunction) => {
  if (error instanceof ZodError) return res.status(400).json({ error: 'VALIDATION_ERROR', message: error.issues[0]?.message || 'Invalid request.' });
  console.error(error);
  return res.status(500).json({ error: 'REQUEST_FAILED', message: 'The server could not complete that request. Please try again.' });
});

app.use(express.static(clientDir, { index: false, maxAge: '1h' }));
app.get('*', (_req, res) => res.sendFile(path.join(clientDir, 'index.html')));

const port = Number(process.env.PORT || 3000);
initializeDatabase().then(() => app.listen(port, '0.0.0.0', () => console.log(`TaskFlow server listening on ${port}`))).catch((error) => { console.error('TaskFlow failed to initialize persistent storage.', error); process.exit(1); });
