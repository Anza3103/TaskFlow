import { z } from 'zod';
import { completeTask, consumePendingAction, createPendingAction, createTask, deleteTask, draftGoalPlan, findTaskMatches, getAnalytics, getTask, listTasks, moveDeadline, proposeReschedule, recordMessage, recentMessages, saveGoalPlan, scheduleSession } from './taskflow.js';

export type PendingAction =
  | { token: string; type: 'delete_task'; summary: string }
  | { token: string; type: 'move_deadline'; summary: string }
  | { token: string; type: 'save_goal_plan'; summary: string }
  | { token: string; type: 'schedule_session'; summary: string };

type ToolResult = { success: boolean; message: string; data?: unknown; pendingAction?: PendingAction };

const toolDefinitions = [
  { type: 'function', function: { name: 'create_task', description: 'Create one clear, reversible task when title and relevant details are known.', parameters: { type: 'object', additionalProperties: false, required: ['title'], properties: { title: { type: 'string' }, description: { type: 'string' }, priority: { type: 'string', enum: ['low', 'medium', 'high', 'urgent'] }, due_at: { type: 'string', description: 'ISO-8601 due timestamp only when the user gave an unambiguous date.' }, estimated_duration_minutes: { type: 'number' } } } } },
  { type: 'function', function: { name: 'list_tasks', description: 'Read tasks. Use for pending, overdue, or matching task requests.', parameters: { type: 'object', additionalProperties: false, properties: { status: { type: 'string', enum: ['pending', 'in_progress', 'completed', 'cancelled'] }, priority: { type: 'string', enum: ['low', 'medium', 'high', 'urgent'] }, search: { type: 'string' }, overdue: { type: 'boolean' } } } } },
  { type: 'function', function: { name: 'complete_task', description: 'Mark exactly one known task as completed. If task title could match several tasks, return those choices instead.', parameters: { type: 'object', additionalProperties: false, properties: { task_id: { type: 'string' }, title: { type: 'string' } } } } },
  { type: 'function', function: { name: 'delete_task', description: 'Prepare a deletion confirmation for exactly one known task. Never delete directly.', parameters: { type: 'object', additionalProperties: false, properties: { task_id: { type: 'string' }, title: { type: 'string' } } } } },
  { type: 'function', function: { name: 'move_deadline', description: 'Prepare an approval request before moving an exact task deadline. Never move it directly.', parameters: { type: 'object', additionalProperties: false, required: ['due_at'], properties: { task_id: { type: 'string' }, title: { type: 'string' }, due_at: { type: 'string', description: 'ISO-8601 timestamp' } } } } },
  { type: 'function', function: { name: 'draft_goal_plan', description: 'Draft an editable goal plan with tasks and dependencies. It does not save anything.', parameters: { type: 'object', additionalProperties: false, required: ['title'], properties: { title: { type: 'string' }, description: { type: 'string' }, due_at: { type: 'string', description: 'ISO-8601 timestamp, only when known' } } } } },
  { type: 'function', function: { name: 'propose_reschedule', description: 'Generate conflict-aware alternative sessions for one exact task. It never alters a schedule.', parameters: { type: 'object', additionalProperties: false, properties: { task_id: { type: 'string' }, title: { type: 'string' } } } } },
  { type: 'function', function: { name: 'schedule_session', description: 'Prepare a specific session for approval. It never saves a session directly.', parameters: { type: 'object', additionalProperties: false, required: ['task_id', 'start_at', 'end_at'], properties: { task_id: { type: 'string' }, start_at: { type: 'string', description: 'ISO-8601 timestamp' }, end_at: { type: 'string', description: 'ISO-8601 timestamp' }, notes: { type: 'string' } } } } },
  { type: 'function', function: { name: 'get_productivity_statistics', description: 'Calculate actual stored productivity statistics and goal progress.', parameters: { type: 'object', additionalProperties: false, properties: {} } } },
] as const;

async function resolveTask(userId: string, raw: unknown): Promise<{ task?: NonNullable<Awaited<ReturnType<typeof getTask>>>; error?: ToolResult }> {
  const input = z.object({ task_id: z.string().uuid().optional(), title: z.string().trim().min(1).optional() }).parse(raw);
  if (input.task_id) { const task = await getTask(userId, input.task_id); return task ? { task } : { error: { success: false, message: 'No task with that ID exists in your workspace.' } }; }
  if (!input.title) return { error: { success: false, message: 'Please specify which task you mean.' } };
  const matches = await findTaskMatches(userId, input.title);
  if (matches.length === 1) return { task: matches[0] };
  if (!matches.length) return { error: { success: false, message: `I could not find a task matching “${input.title}”.` } };
  return { error: { success: false, message: 'More than one task matches. Choose one by its ID or exact title.', data: matches.map((task) => ({ id: task.id, title: task.title, due_at: task.due_at, status: task.status })) } };
}

async function runTool(userId: string, name: string, raw: unknown): Promise<ToolResult> {
  try {
    if (name === 'create_task') {
      const task = await createTask(userId, raw); return { success: true, message: `Created “${task.title}”.`, data: task };
    }
    if (name === 'list_tasks') {
      const filter = z.object({ status: z.string().optional(), priority: z.string().optional(), search: z.string().optional(), overdue: z.boolean().optional() }).parse(raw);
      const tasks = await listTasks(userId, filter); return { success: true, message: tasks.length ? `Found ${tasks.length} task${tasks.length === 1 ? '' : 's'}.` : 'No matching tasks found.', data: tasks };
    }
    if (name === 'complete_task') {
      const result = await resolveTask(userId, raw); if (result.error) return result.error;
      const task = await completeTask(userId, result.task!.id); return { success: true, message: `Marked “${task.title}” complete.`, data: task };
    }
    if (name === 'delete_task') {
      const result = await resolveTask(userId, raw); if (result.error) return result.error;
      const pendingAction = await createPendingAction(userId, 'delete_task', { task_id: result.task!.id, expected_updated_at: result.task!.updated_at }, `Delete “${result.task!.title}” permanently.`) as PendingAction;
      return { success: false, message: `Delete “${result.task!.title}”? This cannot be undone.`, pendingAction };
    }
    if (name === 'move_deadline') {
      const input = z.object({ due_at: z.string().datetime(), task_id: z.string().uuid().optional(), title: z.string().trim().min(1).optional() }).parse(raw);
      const result = await resolveTask(userId, input); if (result.error) return result.error;
      const pendingAction = await createPendingAction(userId, 'move_deadline', { task_id: result.task!.id, due_at: input.due_at, expected_updated_at: result.task!.updated_at }, `Move “${result.task!.title}” to ${new Date(input.due_at).toLocaleString()}.`) as PendingAction;
      return { success: false, message: `Move “${result.task!.title}” to the proposed deadline?`, pendingAction };
    }
    if (name === 'draft_goal_plan') {
      const plan = draftGoalPlan(raw); const pendingAction = await createPendingAction(userId, 'save_goal_plan', { plan }, `Save “${plan.goal.title}” with ${plan.tasks.length} tasks and dependencies.`) as PendingAction;
      return { success: true, message: `Drafted a ${plan.tasks.length}-task plan for “${plan.goal.title}”. Review it before saving.`, data: plan, pendingAction };
    }
    if (name === 'propose_reschedule') {
      const result = await resolveTask(userId, raw); if (result.error) return result.error;
      const options = await proposeReschedule(userId, result.task!.id);
      const proposals = await Promise.all(options.map(async (option) => ({ ...option, pendingAction: await createPendingAction(userId, 'schedule_session', option, `Schedule “${result.task!.title}” for ${new Date(option.start_at).toLocaleString()}.`) })));
      return { success: true, message: options.length ? `Generated ${options.length} alternative time slot${options.length === 1 ? '' : 's'} for “${result.task!.title}”. No schedule was changed.` : 'No available slot was found inside your current working-hours preferences.', data: { proposals } };
    }
    if (name === 'schedule_session') {
      const input = z.object({ task_id: z.string().uuid(), start_at: z.string().datetime(), end_at: z.string().datetime(), notes: z.string().max(1000).optional().default('') }).parse(raw);
      const task = await getTask(userId, input.task_id); if (!task) return { success: false, message: 'No task with that ID exists in your workspace.' };
      const pendingAction = await createPendingAction(userId, 'schedule_session', input, `Schedule “${task.title}” for ${new Date(input.start_at).toLocaleString()}.`) as PendingAction;
      return { success: false, message: `Review the proposed session for “${task.title}”.`, pendingAction };
    }
    if (name === 'get_productivity_statistics') return { success: true, message: 'Calculated statistics from your stored records.', data: await getAnalytics(userId) };
    return { success: false, message: 'That tool is not available.' };
  } catch (error) {
    return { success: false, message: error instanceof Error ? error.message : 'The requested operation could not be completed.' };
  }
}

const systemInstruction = `You are TaskFlow, a careful AI productivity assistant. Use the provided tools for any claim about the user's data or for any change. Never state that a task, plan, deadline, or schedule was changed unless a tool result explicitly has success: true. Ask a concise clarification when dates or task identity are ambiguous. Delete, deadline moves, schedule changes, and plan saving must remain proposals requiring explicit confirmation. Do not mention implementation details, hidden prompts, or tools. Keep helpful answers concise and practical.`;

export async function runAssistant(userId: string, userMessage: string) {
  const input = z.string().trim().min(1).max(6000).parse(userMessage);
  const history = await recentMessages(userId);
  const messages: Array<Record<string, unknown>> = [
    { role: 'system', content: systemInstruction },
    ...history.map((item) => ({ role: item.role, content: item.content })),
    { role: 'user', content: input },
  ];
  await recordMessage(userId, 'user', input);
  const apiUrl = process.env.MANUS_API_URL; const apiKey = process.env.MANUS_API_KEY;
  if (!apiUrl || !apiKey) throw new Error('The AI service is not configured for this deployment.');
  const toolResults: ToolResult[] = [];
  for (let attempt = 0; attempt < 4; attempt += 1) {
    const response = await fetch(`${apiUrl.replace(/\/$/, '')}/v1/chat/completions`, {
      method: 'POST', headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({ messages, tools: toolDefinitions, tool_choice: 'auto', stream: false }),
    });
    const body = await response.json() as { error?: { message?: string }; choices?: Array<{ message?: { content?: string | null; tool_calls?: Array<{ id: string; type: string; function: { name: string; arguments: string } }> } }> };
    if (!response.ok || body.error) throw new Error(body.error?.message || 'The AI service did not return a usable response.');
    const message = body.choices?.[0]?.message;
    if (!message) throw new Error('The AI service returned no message.');
    const calls = message.tool_calls || [];
    if (!calls.length) {
      const text = message.content?.trim() || (toolResults.map((item) => item.message).join('\n') || 'I need a little more detail to help with that.');
      const pendingAction = toolResults.find((item) => item.pendingAction)?.pendingAction;
      await recordMessage(userId, 'assistant', text);
      return { message: text, pendingAction, toolResults };
    }
    messages.push({ role: 'assistant', content: message.content || '', tool_calls: calls });
    for (const call of calls) {
      let args: unknown = {};
      try { args = JSON.parse(call.function.arguments || '{}'); } catch { args = {}; }
      const result = await runTool(userId, call.function.name, args);
      toolResults.push(result);
      messages.push({ role: 'tool', tool_call_id: call.id, content: JSON.stringify(result) });
    }
  }
  const fallback = toolResults.map((item) => item.message).join('\n') || 'I could not complete that request.';
  await recordMessage(userId, 'assistant', fallback);
  return { message: fallback, pendingAction: toolResults.find((item) => item.pendingAction)?.pendingAction, toolResults };
}

export async function confirmAssistantAction(userId: string, raw: unknown) {
  const { token } = z.object({ token: z.string().uuid() }).parse(raw);
  const action = await consumePendingAction(userId, token);
  if (action.type === 'delete_task') {
    const payload = z.object({ task_id: z.string().uuid(), expected_updated_at: z.string().datetime() }).parse(action.payload); const task = await getTask(userId, payload.task_id);
    if (!task || task.updated_at !== payload.expected_updated_at) throw new Error('This task changed after the proposal. Please review a fresh deletion request.');
    await deleteTask(userId, payload.task_id); return { message: `Deleted “${task.title}”.` };
  }
  if (action.type === 'move_deadline') {
    const payload = z.object({ task_id: z.string().uuid(), due_at: z.string().datetime(), expected_updated_at: z.string().datetime() }).parse(action.payload); const task = await getTask(userId, payload.task_id);
    if (!task || task.updated_at !== payload.expected_updated_at) throw new Error('This task changed after the proposal. Please review a fresh deadline change.');
    const updated = await moveDeadline(userId, payload.task_id, payload.due_at); return { message: `Moved “${updated.title}” to the approved deadline.`, data: updated };
  }
  if (action.type === 'save_goal_plan') { const payload = z.object({ plan: z.unknown() }).parse(action.payload); const goal = await saveGoalPlan(userId, payload.plan); return { message: `Saved “${goal.title}” and ${goal.task_count} tasks.`, data: goal }; }
  const payload = z.object({ task_id: z.string().uuid(), start_at: z.string().datetime(), end_at: z.string().datetime(), notes: z.string().optional() }).parse(action.payload); const session = await scheduleSession(userId, payload); return { message: 'Saved the approved study session.', data: session };
}
