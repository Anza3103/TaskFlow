import test from 'node:test';
import assert from 'node:assert/strict';
import { draftGoalPlan } from './taskflow.js';

test('draftGoalPlan creates an ordered, dependency-safe task plan', () => {
  const plan = draftGoalPlan({ title: 'Prepare for AI exam', description: 'Focus on search and planning.' });
  assert.equal(plan.milestones.length, 3);
  assert.equal(plan.tasks.length, 4);
  assert.deepEqual(plan.tasks[0].depends_on_indexes, []);
  assert.deepEqual(plan.tasks[3].depends_on_indexes, [2]);
  assert.equal(plan.goal.title, 'Prepare for AI exam');
});
