import crypto from 'node:crypto';
import { DateTime } from 'luxon';
import { z } from 'zod';
import { execute, getPool, query, toIso, toSqlDate, withTransaction } from './db.js';

const priority = z.enum(['low', 'medium', 'high', 'urgent']);
const status = z.enum(['pending', 'in_progress', 'completed', 'cancelled']);
export const taskInput = z.object({
  title: z.string().trim().min(1).max(240),
  description: z.string().max(5000).optional().default(''),
  priority: priority.optional().default('medium'),
  due_at: z.string().datetime().nullable().optional(),
  estimated_duration_minutes: z.number().int().min(5).max(1440).optional().default(45),
});
export type TaskInput = z.infer<typeof taskInput>;

type DbTask = { id: string; title: string; description: string; status: z.infer<typeof status>; priority: z.infer<typeof priority>; due_at: string | null; estimated_duration_minutes: number; actual_duration_minutes: number | null; goal_id: string | null; milestone_id: string | null; created_at: string; updated_at: string };

function serializeTask(row: DbTask) {
  return { ...row, due_at: toIso(row.due_at), created_at: toIso(row.created_at), updated_at: toIso(row.updated_at) };
}

function cleanTitle(value: string) { return value.trim().replace(/\s+/g, ' '); }

export async function listTasks(userId: string, filters: { status?: string; priority?: string; search?: string; overdue?: boolean } = {}) {
  const where = ['user_id = ?']; const values: unknown[] = [userId];
  if (filters.status && status.safeParse(filters.status).success) { where.push('status = ?'); values.push(filters.status); }
  if (filters.priority && priority.safeParse(filters.priority).success) { where.push('priority = ?'); values.push(filters.priority); }
  if (filters.search) { where.push('(title LIKE ? OR description LIKE ?)'); const term = `%${filters.search.trim()}%`; values.push(term, term); }
  if (filters.overdue) where.push("due_at < UTC_TIMESTAMP() AND status NOT IN ('completed', 'cancelled')");
  const rows = await query<DbTask[]>(`SELECT id, title, description, status, priority, due_at, estimated_duration_minutes, actual_duration_minutes, goal_id, milestone_id, created_at, updated_at FROM tasks WHERE ${where.join(' AND ')} ORDER BY due_at IS NULL, due_at ASC, created_at DESC`, values);
  return rows.map(serializeTask);
}

export async function getTask(userId: string, taskId: string) {
  const rows = await query<DbTask[]>('SELECT id, title, description, status, priority, due_at, estimated_duration_minutes, actual_duration_minutes, goal_id, milestone_id, created_at, updated_at FROM tasks WHERE id = ? AND user_id = ?', [taskId, userId]);
  return rows[0] ? serializeTask(rows[0]) : null;
}

export async function findTaskMatches(userId: string, title: string) {
  const rows = await query<DbTask[]>('SELECT id, title, description, status, priority, due_at, estimated_duration_minutes, actual_duration_minutes, goal_id, milestone_id, created_at, updated_at FROM tasks WHERE user_id = ? AND title LIKE ? ORDER BY updated_at DESC LIMIT 8', [userId, `%${cleanTitle(title)}%`]);
  return rows.map(serializeTask);
}

export async function createTask(userId: string, raw: unknown) {
  const input = taskInput.parse(raw); const id = crypto.randomUUID();
  await execute('INSERT INTO tasks (id, user_id, title, description, priority, due_at, estimated_duration_minutes) VALUES (?, ?, ?, ?, ?, ?, ?)', [id, userId, cleanTitle(input.title), input.description.trim(), input.priority, toSqlDate(input.due_at), input.estimated_duration_minutes]);
  const task = await getTask(userId, id); if (!task) throw new Error('Task was not persisted.');
  return task;
}

export async function updateTask(userId: string, taskId: string, raw: unknown) {
  const input = z.object({ title: z.string().trim().min(1).max(240).optional(), description: z.string().max(5000).optional(), priority: priority.optional(), status: status.optional(), estimated_duration_minutes: z.number().int().min(5).max(1440).optional(), actual_duration_minutes: z.number().int().min(0).max(100000).nullable().optional() }).parse(raw);
  const task = await getTask(userId, taskId); if (!task) throw new Error('Task not found.');
  const parts: string[] = []; const values: unknown[] = [];
  for (const [key, value] of Object.entries(input)) { parts.push(`${key} = ?`); values.push(key === 'title' ? cleanTitle(String(value)) : value); }
  if (!parts.length) return task;
  await execute(`UPDATE tasks SET ${parts.join(', ')} WHERE id = ? AND user_id = ?`, [...values, taskId, userId]);
  const updated = await getTask(userId, taskId); if (!updated) throw new Error('Task was not persisted.'); return updated;
}

export async function completeTask(userId: string, taskId: string) {
  const task = await getTask(userId, taskId); if (!task) throw new Error('Task not found.');
  await execute("UPDATE tasks SET status = 'completed', completed_at = UTC_TIMESTAMP() WHERE id = ? AND user_id = ?", [taskId, userId]);
  const completed = await getTask(userId, taskId); if (!completed) throw new Error('Task was not persisted.'); return completed;
}

export async function deleteTask(userId: string, taskId: string) {
  const task = await getTask(userId, taskId); if (!task) throw new Error('Task not found.');
  await execute('DELETE FROM tasks WHERE id = ? AND user_id = ?', [taskId, userId]);
  return task;
}

export async function moveDeadline(userId: string, taskId: string, dueAt: string) {
  const task = await getTask(userId, taskId); if (!task) throw new Error('Task not found.');
  await execute('UPDATE tasks SET due_at = ? WHERE id = ? AND user_id = ?', [toSqlDate(dueAt), taskId, userId]);
  const updated = await getTask(userId, taskId); if (!updated) throw new Error('Task was not persisted.'); return updated;
}

export async function getPreferences(userId: string) {
  const rows = await query<Array<{ timezone: string; work_start_hour: number; work_end_hour: number; default_duration_minutes: number; break_minutes: number; working_days: string; planning_style: string }>>('SELECT timezone, work_start_hour, work_end_hour, default_duration_minutes, break_minutes, working_days, planning_style FROM preferences WHERE user_id = ?', [userId]);
  return rows[0] || { timezone: 'Asia/Karachi', work_start_hour: 9, work_end_hour: 18, default_duration_minutes: 45, break_minutes: 10, working_days: '1,2,3,4,5', planning_style: 'balanced' };
}

export async function updatePreferences(userId: string, raw: unknown) {
  const input = z.object({ timezone: z.string().trim().min(1).max(64), work_start_hour: z.number().int().min(0).max(23), work_end_hour: z.number().int().min(1).max(23), default_duration_minutes: z.number().int().min(5).max(1440), break_minutes: z.number().int().min(0).max(120), working_days: z.string().regex(/^[0-6](,[0-6])*$/), planning_style: z.enum(['balanced', 'focused', 'deadline-first']) }).refine((data) => data.work_end_hour > data.work_start_hour, { message: 'Work end must be after work start.' }).parse(raw);
  await execute('UPDATE preferences SET timezone = ?, work_start_hour = ?, work_end_hour = ?, default_duration_minutes = ?, break_minutes = ?, working_days = ?, planning_style = ? WHERE user_id = ?', [input.timezone, input.work_start_hour, input.work_end_hour, input.default_duration_minutes, input.break_minutes, input.working_days, input.planning_style, userId]);
  return getPreferences(userId);
}

export type GoalPlan = { goal: { title: string; description: string; due_at: string | null }; milestones: Array<{ title: string; sequence: number }>; tasks: Array<{ title: string; description: string; priority: z.infer<typeof priority>; estimated_duration_minutes: number; due_at: string | null; milestone_index: number; depends_on_indexes: number[] }> };

export function draftGoalPlan(raw: unknown): GoalPlan {
  const input = z.object({ title: z.string().trim().min(1).max(200), description: z.string().max(5000).optional().default(''), due_at: z.string().datetime().nullable().optional() }).parse(raw);
  const start = new Date(); start.setUTCDate(start.getUTCDate() + 1); const due = input.due_at ? new Date(input.due_at) : new Date(start.getTime() + 14 * 86400000);
  const dates = [0.22, 0.5, 0.74, 1].map((fraction) => new Date(start.getTime() + (due.getTime() - start.getTime()) * fraction).toISOString());
  return { goal: { title: cleanTitle(input.title), description: input.description.trim(), due_at: due.toISOString() }, milestones: [{ title: 'Clarify the outcome', sequence: 1 }, { title: 'Make focused progress', sequence: 2 }, { title: 'Review and finish', sequence: 3 }], tasks: [
    { title: `Define success criteria for ${cleanTitle(input.title)}`, description: 'Capture the outcome, required resources, and constraints.', priority: 'high', estimated_duration_minutes: 45, due_at: dates[0], milestone_index: 0, depends_on_indexes: [] },
    { title: `Complete the first focused block for ${cleanTitle(input.title)}`, description: 'Work through the first meaningful chunk without multitasking.', priority: 'high', estimated_duration_minutes: 60, due_at: dates[1], milestone_index: 1, depends_on_indexes: [0] },
    { title: `Review progress on ${cleanTitle(input.title)}`, description: 'Identify gaps and resolve open questions.', priority: 'medium', estimated_duration_minutes: 45, due_at: dates[2], milestone_index: 2, depends_on_indexes: [1] },
    { title: `Finish and verify ${cleanTitle(input.title)}`, description: 'Complete outstanding work and verify the defined criteria.', priority: 'high', estimated_duration_minutes: 60, due_at: dates[3], milestone_index: 2, depends_on_indexes: [2] },
  ] };
}

export function validateGoalPlan(raw: unknown): GoalPlan {
  const plan = z.object({ goal: z.object({ title: z.string().min(1).max(200), description: z.string().max(5000), due_at: z.string().datetime().nullable() }), milestones: z.array(z.object({ title: z.string().min(1).max(200), sequence: z.number().int().min(1) })).min(1), tasks: z.array(z.object({ title: z.string().min(1).max(240), description: z.string().max(5000), priority, estimated_duration_minutes: z.number().int().min(5).max(1440), due_at: z.string().datetime().nullable(), milestone_index: z.number().int().min(0), depends_on_indexes: z.array(z.number().int().min(0)) })).min(1) }).parse(raw);
  plan.tasks.forEach((task, index) => task.depends_on_indexes.forEach((dependency) => { if (dependency === index || dependency >= plan.tasks.length) throw new Error('Invalid task dependency.'); }));
  const visiting = new Set<number>(); const visited = new Set<number>();
  const visit = (index: number): boolean => { if (visiting.has(index)) return true; if (visited.has(index)) return false; visiting.add(index); if (plan.tasks[index].depends_on_indexes.some(visit)) return true; visiting.delete(index); visited.add(index); return false; };
  if (plan.tasks.some((_, index) => visit(index))) throw new Error('Task dependencies cannot form a cycle.');
  return plan;
}

export async function saveGoalPlan(userId: string, raw: unknown) {
  const plan = validateGoalPlan(raw); const goalId = crypto.randomUUID();
  await withTransaction(async (connection) => {
    await connection.execute('INSERT INTO goals (id, user_id, title, description, due_at) VALUES (?, ?, ?, ?, ?)', [goalId, userId, cleanTitle(plan.goal.title), plan.goal.description, toSqlDate(plan.goal.due_at)]);
    const milestoneIds: string[] = [];
    for (const milestone of plan.milestones) { const id = crypto.randomUUID(); milestoneIds.push(id); await connection.execute('INSERT INTO milestones (id, goal_id, title, sequence_number) VALUES (?, ?, ?, ?)', [id, goalId, milestone.title, milestone.sequence]); }
    const taskIds: string[] = [];
    for (const task of plan.tasks) { const id = crypto.randomUUID(); taskIds.push(id); const milestoneId = milestoneIds[task.milestone_index] || null; await connection.execute('INSERT INTO tasks (id, user_id, title, description, priority, due_at, estimated_duration_minutes, goal_id, milestone_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)', [id, userId, cleanTitle(task.title), task.description, task.priority, toSqlDate(task.due_at), task.estimated_duration_minutes, goalId, milestoneId]); }
    for (let index = 0; index < plan.tasks.length; index += 1) for (const dependency of plan.tasks[index].depends_on_indexes) await connection.execute('INSERT INTO task_dependencies (task_id, depends_on_task_id) VALUES (?, ?)', [taskIds[index], taskIds[dependency]]);
  });
  return { goal_id: goalId, title: plan.goal.title, task_count: plan.tasks.length };
}

export async function listGoals(userId: string) {
  const goals = await query<Array<{ id: string; title: string; description: string; status: string; due_at: string | null; created_at: string }>>('SELECT id, title, description, status, due_at, created_at FROM goals WHERE user_id = ? ORDER BY created_at DESC', [userId]);
  const result = [];
  for (const goal of goals) {
    const totals = await query<Array<{ total: number; completed: number }>>(`SELECT COUNT(*) AS total, SUM(status = 'completed') AS completed FROM tasks WHERE goal_id = ?`, [goal.id]);
    result.push({ ...goal, due_at: toIso(goal.due_at), created_at: toIso(goal.created_at), total_tasks: Number(totals[0]?.total || 0), completed_tasks: Number(totals[0]?.completed || 0) });
  }
  return result;
}

export async function listSessions(userId: string) {
  const rows = await query<Array<{ id: string; task_id: string; task_title: string; start_at: string; end_at: string; notes: string }>>('SELECT s.id, s.task_id, t.title AS task_title, s.start_at, s.end_at, s.notes FROM scheduled_sessions s JOIN tasks t ON t.id = s.task_id WHERE t.user_id = ? AND s.end_at >= UTC_TIMESTAMP() - INTERVAL 1 DAY ORDER BY s.start_at ASC LIMIT 100', [userId]);
  return rows.map((row) => ({ ...row, start_at: toIso(row.start_at)!, end_at: toIso(row.end_at)! }));
}

export async function proposeReschedule(userId: string, taskId: string) {
  const task = await getTask(userId, taskId); if (!task) throw new Error('Task not found.');
  const prefs = await getPreferences(userId); const sessions = await listSessions(userId); const proposals: Array<{ task_id: string; start_at: string; end_at: string; explanation: string }> = [];
  const workDays = new Set(prefs.working_days.split(',').map(Number)); const now = DateTime.now().setZone(prefs.timezone);
  for (let day = 0; day < 10 && proposals.length < 3; day += 1) {
    const date = now.startOf('day').plus({ days: day });
    if (!workDays.has(date.weekday)) continue;
    const endBoundary = date.set({ hour: prefs.work_end_hour, minute: 0 });
    for (let cursor = date.set({ hour: prefs.work_start_hour, minute: 0 }); cursor.plus({ minutes: task.estimated_duration_minutes }) <= endBoundary; cursor = cursor.plus({ minutes: 30 })) {
      const end = cursor.plus({ minutes: task.estimated_duration_minutes });
      if (cursor <= now) continue;
      const clash = sessions.some((session) => DateTime.fromISO(session.start_at).toUTC() < end.toUTC() && DateTime.fromISO(session.end_at).toUTC() > cursor.toUTC());
      if (!clash) proposals.push({ task_id: task.id, start_at: cursor.toUTC().toISO()!, end_at: end.toUTC().toISO()!, explanation: `Fits within your ${prefs.timezone} working hours and avoids stored sessions.` });
      if (proposals.length >= 3) break;
    }
  }
  return proposals;
}

export async function scheduleSession(userId: string, raw: unknown) {
  const input = z.object({ task_id: z.string().uuid(), start_at: z.string().datetime(), end_at: z.string().datetime(), notes: z.string().max(1000).optional().default('') }).refine((data) => new Date(data.end_at) > new Date(data.start_at), { message: 'End time must be after start time.' }).parse(raw);
  const prefs = await getPreferences(userId); const start = DateTime.fromISO(input.start_at, { setZone: true }).setZone(prefs.timezone); const end = DateTime.fromISO(input.end_at, { setZone: true }).setZone(prefs.timezone);
  const workDays = new Set(prefs.working_days.split(',').map(Number));
  const startHour = start.hour + start.minute / 60; const endHour = end.hour + end.minute / 60;
  if (!start.isValid || !end.isValid || start.weekday !== end.weekday || !workDays.has(start.weekday) || startHour < prefs.work_start_hour || endHour > prefs.work_end_hour) throw new Error(`Sessions must fit inside your configured ${prefs.timezone} working hours.`);
  return withTransaction(async (connection) => {
    const lockName = `taskflow:schedule:${userId}`;
    const [locks] = await connection.query('SELECT GET_LOCK(?, 5) AS locked', [lockName]) as unknown as [Array<{ locked: number }>, unknown];
    if (Number(locks[0]?.locked) !== 1) throw new Error('Could not reserve the schedule for conflict checking. Please try again.');
    try {
      const [tasks] = await connection.execute('SELECT id FROM tasks WHERE id = ? AND user_id = ? FOR UPDATE', [input.task_id, userId]) as unknown as [Array<{ id: string }>, unknown];
      if (!tasks.length) throw new Error('Task not found.');
      const [overlapping] = await connection.execute('SELECT s.id FROM scheduled_sessions s JOIN tasks t ON t.id = s.task_id WHERE t.user_id = ? AND s.start_at < ? AND s.end_at > ? FOR UPDATE', [userId, toSqlDate(input.end_at), toSqlDate(input.start_at)]) as unknown as [Array<{ id: string }>, unknown];
      if (overlapping.length) throw new Error('The proposed session overlaps an existing session.');
      const id = crypto.randomUUID(); await connection.execute('INSERT INTO scheduled_sessions (id, task_id, start_at, end_at, notes) VALUES (?, ?, ?, ?, ?)', [id, input.task_id, toSqlDate(input.start_at), toSqlDate(input.end_at), input.notes]);
      return { id, ...input };
    } finally { await connection.query('SELECT RELEASE_LOCK(?)', [lockName]); }
  });
}

const pendingActionType = z.enum(['delete_task', 'move_deadline', 'save_goal_plan', 'schedule_session']);
export type PendingActionRecord = { token: string; type: z.infer<typeof pendingActionType>; summary: string };

export async function createPendingAction(userId: string, type: z.infer<typeof pendingActionType>, payload: unknown, summary: string): Promise<PendingActionRecord> {
  const token = crypto.randomUUID(); const expiresAt = new Date(Date.now() + 15 * 60 * 1000);
  await execute('INSERT INTO pending_actions (id, user_id, action_type, payload, summary, expires_at) VALUES (?, ?, ?, ?, ?, ?)', [token, userId, type, JSON.stringify(payload), summary.slice(0, 1000), toSqlDate(expiresAt)]);
  return { token, type, summary };
}

export async function consumePendingAction(userId: string, token: string) {
  const rows = await query<Array<{ action_type: string; payload: string | object; summary: string }>>('SELECT action_type, payload, summary FROM pending_actions WHERE id = ? AND user_id = ? AND consumed_at IS NULL AND expires_at > UTC_TIMESTAMP()', [token, userId]);
  if (!rows[0]) throw new Error('This approval has expired or was already used. Create a fresh proposal and try again.');
  const updated = await execute('UPDATE pending_actions SET consumed_at = UTC_TIMESTAMP() WHERE id = ? AND user_id = ? AND consumed_at IS NULL AND expires_at > UTC_TIMESTAMP()', [token, userId]);
  if (updated.affectedRows !== 1) throw new Error('This approval has expired or was already used. Create a fresh proposal and try again.');
  const row = rows[0]; return { type: pendingActionType.parse(row.action_type), payload: typeof row.payload === 'string' ? JSON.parse(row.payload) : row.payload, summary: row.summary };
}

export async function getAnalytics(userId: string) {
  const rows = await query<Array<{ total: number; completed: number; pending: number; overdue: number; estimated_minutes: number; actual_minutes: number }>>(`SELECT COUNT(*) AS total, SUM(status = 'completed') AS completed, SUM(status IN ('pending','in_progress')) AS pending, SUM(due_at < UTC_TIMESTAMP() AND status NOT IN ('completed','cancelled')) AS overdue, SUM(estimated_duration_minutes) AS estimated_minutes, SUM(COALESCE(actual_duration_minutes,0)) AS actual_minutes FROM tasks WHERE user_id = ?`, [userId]);
  const value = rows[0] || { total: 0, completed: 0, pending: 0, overdue: 0, estimated_minutes: 0, actual_minutes: 0 };
  const total = Number(value.total || 0); const completed = Number(value.completed || 0);
  const weeklyRows = await query<Array<{ week: string; completed: number }>>(`SELECT DATE_FORMAT(completed_at, '%x-W%v') AS week, COUNT(*) AS completed FROM tasks WHERE user_id = ? AND status = 'completed' AND completed_at >= UTC_TIMESTAMP() - INTERVAL 8 WEEK GROUP BY week ORDER BY week`, [userId]);
  const goalProgress = await listGoals(userId);
  return { summary: { total, completed, pending: Number(value.pending || 0), overdue: Number(value.overdue || 0), completion_percentage: total ? Math.round((completed / total) * 100) : 0, estimated_minutes: Number(value.estimated_minutes || 0), actual_minutes: Number(value.actual_minutes || 0) }, weekly_completion: weeklyRows.map((row) => ({ week: row.week, completed: Number(row.completed) })), goal_progress: goalProgress.map((goal) => ({ goal: goal.title, total: goal.total_tasks, completed: goal.completed_tasks, progress: goal.total_tasks ? Math.round((goal.completed_tasks / goal.total_tasks) * 100) : 0 })) };
}

export async function recordMessage(userId: string, role: 'user' | 'assistant', content: string) {
  await execute('INSERT INTO conversation_messages (id, user_id, role, content) VALUES (?, ?, ?, ?)', [crypto.randomUUID(), userId, role, content.slice(0, 12000)]);
}

export async function recentMessages(userId: string) {
  const rows = await query<Array<{ role: 'user' | 'assistant'; content: string }>>('SELECT role, content FROM conversation_messages WHERE user_id = ? ORDER BY created_at DESC LIMIT 12', [userId]);
  return rows.reverse();
}

export async function healthCheck() { await getPool().query('SELECT 1'); }
