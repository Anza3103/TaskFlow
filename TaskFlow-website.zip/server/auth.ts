import crypto from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import jwt, { type JwtPayload } from 'jsonwebtoken';
import { execute } from './db.js';

export type TaskFlowUser = { id: string; name: string; email?: string };

declare global {
  namespace Express {
    interface Request { taskflowUser?: TaskFlowUser }
  }
}

const sessionCookie = 'webdev_app_session';
const stateCookie = 'taskflow_oauth_state';

function secret(): string {
  const value = process.env.MANUS_JWT_SECRET || process.env.JWT_SECRET;
  if (!value) throw new Error('MANUS_JWT_SECRET is not configured.');
  return value;
}

function cookieOptions() {
  return { httpOnly: true, secure: true, sameSite: 'none' as const, path: '/', maxAge: 1000 * 60 * 60 * 24 * 30 };
}

function getSession(token: string): JwtPayload {
  const decoded = jwt.verify(token, secret(), { algorithms: ['HS256'] });
  if (typeof decoded === 'string') throw new Error('Invalid session payload.');
  const appId = process.env.MANUS_PROJECT_ID;
  if (appId && decoded.appId && decoded.appId !== appId) throw new Error('Session is for another application.');
  return decoded;
}

async function provisionUser(id: string, name?: string, email?: string): Promise<TaskFlowUser> {
  const displayName = (name || 'TaskFlow user').slice(0, 160);
  await execute(
    `INSERT INTO users (id, name, email) VALUES (?, ?, ?)
     ON DUPLICATE KEY UPDATE name = VALUES(name), email = COALESCE(VALUES(email), email), last_login_at = CURRENT_TIMESTAMP(3)`,
    [id, displayName, email || null],
  );
  await execute('INSERT IGNORE INTO preferences (user_id) VALUES (?)', [id]);
  return { id, name: displayName, ...(email ? { email } : {}) };
}

export async function requireUser(req: Request, res: Response, next: NextFunction): Promise<void> {
  try {
    const token = req.cookies?.[sessionCookie];
    if (!token) {
      res.status(401).json({ error: 'AUTH_REQUIRED', message: 'Sign in to access your private TaskFlow workspace.' });
      return;
    }
    const payload = getSession(token);
    const id = typeof payload.openId === 'string' ? payload.openId : typeof payload.sub === 'string' ? payload.sub : undefined;
    if (!id) throw new Error('No user identity in session.');
    const name = typeof payload.name === 'string' ? payload.name : typeof payload.displayName === 'string' ? payload.displayName : undefined;
    const email = typeof payload.email === 'string' ? payload.email : undefined;
    req.taskflowUser = await provisionUser(id, name, email);
    next();
  } catch {
    res.status(401).json({ error: 'AUTH_REQUIRED', message: 'Your session has expired. Please sign in again.' });
  }
}

function approvedOrigin(candidate: unknown): string {
  if (typeof candidate !== 'string') throw new Error('A browser origin is required for sign-in.');
  const parsed = new URL(candidate);
  const configured = (process.env.TASKFLOW_ALLOWED_ORIGINS || '').split(',').map((origin) => origin.trim()).filter(Boolean);
  const isLocal = parsed.protocol === 'http:' && parsed.hostname === 'localhost';
  const isManagedManusHost = parsed.protocol === 'https:' && (parsed.hostname.endsWith('.manus.computer') || parsed.hostname.endsWith('.manus.space'));
  if (!isLocal && !isManagedManusHost && !configured.includes(parsed.origin)) throw new Error('This origin is not approved for TaskFlow sign-in.');
  if (configured.length && !isLocal && !isManagedManusHost && !configured.includes(parsed.origin)) throw new Error('This origin is not approved for TaskFlow sign-in.');
  return parsed.origin;
}

export function startLogin(req: Request, res: Response): void {
  try {
    const origin = approvedOrigin(req.query.origin);
    const nonce = crypto.randomUUID();
    const state = Buffer.from(JSON.stringify({ nonce, origin })).toString('base64url');
    res.cookie(stateCookie, nonce, { ...cookieOptions(), maxAge: 1000 * 60 * 10 });
    const redirectUri = `${origin}/api/auth/callback`;
    const portal = process.env.MANUS_OAUTH_PORTAL_URL;
    const appId = process.env.MANUS_PROJECT_ID;
    if (!portal || !appId) throw new Error('Manus OAuth is not configured.');
    const target = new URL('/app-auth', portal);
    target.searchParams.set('appId', appId);
    target.searchParams.set('redirectUri', redirectUri);
    target.searchParams.set('state', state);
    target.searchParams.set('responseType', 'code');
    res.redirect(target.toString());
  } catch (error) {
    console.error('Unable to start TaskFlow OAuth sign-in.', error);
    res.status(400).send('<h1>Unable to start sign-in</h1><p>Use the approved TaskFlow website URL and try again.</p>');
  }
}

export async function finishLogin(req: Request, res: Response): Promise<void> {
  try {
    const code = typeof req.query.code === 'string' ? req.query.code : '';
    const encodedState = typeof req.query.state === 'string' ? req.query.state : '';
    const state = JSON.parse(Buffer.from(encodedState, 'base64url').toString('utf8')) as { nonce?: string; origin?: string };
    if (!code || !state.nonce || !state.origin || req.cookies?.[stateCookie] !== state.nonce) throw new Error('The sign-in request could not be verified. Please try again.');
    const origin = approvedOrigin(state.origin);
    const redirectUri = `${origin}/api/auth/callback`;
    const authApi = process.env.MANUS_OAUTH_API_URL;
    const clientId = process.env.MANUS_PROJECT_ID;
    if (!authApi || !clientId) throw new Error('Manus OAuth is not configured.');
    const exchange = await fetch(`${authApi}/webdev.v1.WebDevAuthPublicService/ExchangeToken`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ clientId, grantType: 'authorization_code', code, redirectUri }),
    });
    const exchangeBody = await exchange.json() as { accessToken?: string; error?: { message?: string } };
    if (!exchange.ok || !exchangeBody.accessToken) throw new Error(exchangeBody.error?.message || 'Token exchange failed.');
    const identityResponse = await fetch(`${authApi}/webdev.v1.WebDevAuthPublicService/GetUserInfo`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ accessToken: exchangeBody.accessToken }),
    });
    const identity = await identityResponse.json() as { openId?: string; name?: string; email?: string; error?: { message?: string } };
    if (!identityResponse.ok || !identity.openId) throw new Error(identity.error?.message || 'Could not load your identity.');
    const user = await provisionUser(identity.openId, identity.name, identity.email);
    const token = jwt.sign({ openId: user.id, name: user.name, email: user.email, appId: clientId }, secret(), { algorithm: 'HS256', expiresIn: '30d' });
    res.clearCookie(stateCookie, cookieOptions());
    res.cookie(sessionCookie, token, cookieOptions());
    res.redirect(`${origin}/`);
  } catch (error) {
    console.error('TaskFlow OAuth sign-in failed.', error);
    res.status(400).send('<h1>Sign-in failed</h1><p>Your sign-in could not be completed. Please return to TaskFlow and try again.</p>');
  }
}

export function logout(_req: Request, res: Response): void {
  res.clearCookie(sessionCookie, cookieOptions());
  res.status(204).send();
}
