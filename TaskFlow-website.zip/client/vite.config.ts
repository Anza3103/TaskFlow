import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const dirname = fileURLToPath(new URL('.', import.meta.url));

export default defineConfig({
  plugins: [react()],
  root: resolve(dirname),
  publicDir: resolve(dirname, '../public'),
  build: {
    outDir: resolve(dirname, '../dist/client'),
    emptyOutDir: true,
  },
});
