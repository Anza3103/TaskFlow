export type Task = { id: string; title: string; description: string; status: 'pending' | 'in_progress' | 'completed' | 'cancelled'; priority: 'low' | 'medium' | 'high' | 'urgent'; due_at: string | null; estimated_duration_minutes: number; actual_duration_minutes: number | null; goal_id: string | null; milestone_id: string | null; created_at: string; updated_at: string };
export type PendingAction = { token: string; type: 'delete_task' | 'move_deadline' | 'save_goal_plan' | 'schedule_session'; summary: string };
export type Bootstrap = { user: { id: string; name: string; email?: string }; tasks: Task[]; goals: Array<{ id: string; title: string; description: string; due_at: string | null; total_tasks: number; completed_tasks: number }>; sessions: Array<{ id: string; task_id: string; task_title: string; start_at: string; end_at: string; notes: string }>; preferences: Preferences; analytics: Analytics };
export type Preferences = { timezone: string; work_start_hour: number; work_end_hour: number; default_duration_minutes: number; break_minutes: number; working_days: string; planning_style: 'balanced' | 'focused' | 'deadline-first' };
export type Analytics = { summary: { total: number; completed: number; pending: number; overdue: number; completion_percentage: number; estimated_minutes: number; actual_minutes: number }; weekly_completion: Array<{ week: string; completed: number }>; goal_progress: Array<{ goal: string; total: number; completed: number; progress: number }> };

export class ApiError extends Error {
  constructor(public status: number, public body: any) { super(body?.message || 'The request could not be completed.'); }
}

export async function api<T>(path: string, init: RequestInit = {}): Promise<T> {
  const response = await fetch(path, { credentials: 'include', headers: { ...(init.body ? { 'Content-Type': 'application/json' } : {}), ...init.headers }, ...init });
  if (response.status === 204) return undefined as T;
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new ApiError(response.status, body);
  return body as T;
}

export const getBootstrap = () => api<Bootstrap>('/api/bootstrap');
export const createTask = (input: Record<string, unknown>) => api<Task>('/api/tasks', { method: 'POST', body: JSON.stringify(input) });
export const completeTask = (id: string) => api<Task>(`/api/tasks/${id}/complete`, { method: 'POST' });
export const deleteTask = (id: string) => api(`/api/tasks/${id}`, { method: 'DELETE' });
export const updateTask = (id: string, input: Record<string, unknown>) => api<Task>(`/api/tasks/${id}`, { method: 'PATCH', body: JSON.stringify(input) });
export const draftPlan = (input: Record<string, unknown>) => api<any>('/api/goals/draft', { method: 'POST', body: JSON.stringify(input) });
export const proposeGoalPlan = (plan: unknown) => api<{ pendingAction: PendingAction }>('/api/goals/propose', { method: 'POST', body: JSON.stringify(plan) });
export const savePreferences = (input: Preferences) => api<Preferences>('/api/preferences', { method: 'PUT', body: JSON.stringify(input) });
export const sendAssistant = (message: string) => api<{ message: string; pendingAction?: PendingAction; toolResults: Array<{ success: boolean; message: string; data?: unknown; pendingAction?: PendingAction }> }>('/api/assistant', { method: 'POST', body: JSON.stringify({ message }) });
export const confirmAction = (action: PendingAction) => api<{ message: string; data?: unknown }>('/api/assistant/confirm', { method: 'POST', body: JSON.stringify({ token: action.token }) });
