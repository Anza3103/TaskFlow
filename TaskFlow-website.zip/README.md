# TaskFlow

TaskFlow is a full-stack, approval-first AI productivity website. It is not a local demo: the deployed application uses Manus OAuth for private workspaces, a managed MySQL database for durable task data, and the platform LLM from the server for constrained assistant workflows.

## What works

Users can sign in, create and complete tasks, use persistent preferences, view actual analytics, draft goal plans, inspect schedules, and use the AI assistant for controlled task operations. Task deletion, deadline changes, plan saving, and schedule changes are represented as a pending action and only write to the database after explicit approval.

## Architecture

- `client/`: React + TypeScript user interface
- `server/`: Express API, Manus OAuth session handling, AI tool orchestration, and MySQL queries
- `public/`: route manifest and visual assets
- `Dockerfile`: production container definition

The server uses only parameterized SQL and validates request/tool input with Zod. The AI integration is server-side only. The model receives a narrow set of task/goal/scheduling tools and never gets arbitrary code, shell, filesystem, or SQL execution capabilities.

## Local development

A local run requires a MySQL-compatible `DATABASE_URL` and the Manus runtime values listed in `.env.example`:

```bash
pnpm install
pnpm build
pnpm start
```

The managed project provides these credentials in development and deployment automatically. The server starts on `PORT` (default `3000`) and exposes `GET /health`.

Manus-managed preview and published origins are accepted for OAuth by default. If you later attach a custom domain, set `TASKFLOW_ALLOWED_ORIGINS` to that exact HTTPS origin before enabling sign-in from it.

## Checks

```bash
pnpm typecheck
pnpm build
pnpm test
```

## Deployment

The project is configured for a server container deployment. Persistent data lives in the managed database, never on the container filesystem. The app initializes additive tables with `CREATE TABLE IF NOT EXISTS`; it does not reset or seed user data at startup.

## Known boundary

TaskFlow intentionally does not claim external calendar events or notifications have been created because no calendar or notification integration is configured. Its weekly schedule represents stored TaskFlow sessions only.
