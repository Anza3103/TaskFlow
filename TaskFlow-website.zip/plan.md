# TaskFlow implementation plan

## Product direction

TaskFlow will be a real full-stack productivity website rather than a local Streamlit prototype. It will persist task, goal, schedule, preference, and conversation data in the project-managed MySQL database. A browser can create a private TaskFlow workspace after signing in with Manus OAuth; no mocked local data or demo mode will be used. The browser UI calls a same-origin Express API. The API validates every request, operates on the database, and invokes the platform LLM server-side only for agent interpretation and tool-choice.

## Architecture

- **Client:** React + TypeScript + Vite. The application is an accessible single-page workspace with Dashboard, Assistant, Tasks, Goals, Schedule, Analytics, and Settings views.
- **Server:** Express + TypeScript. It serves the built frontend in production, exposes `/api/*` endpoints, owns OAuth/session handling, database access, agent orchestration, and health checks.
- **Persistence:** Managed MySQL via `DATABASE_URL`, initialized idempotently on startup. Tables include app users, preferences, tasks, goals, milestones, dependencies, sessions, and messages. Every query is parameterized.
- **AI:** The server calls `$MANUS_API_URL/v1/chat/completions` with the supplied service credential. Tool definitions are constrained to validated task/goal/scheduling operations; the model cannot execute arbitrary code, SQL, shell commands, or filesystem operations. The UI reports a genuine AI-service failure rather than pretending a result was generated.
- **Safety:** A draft action is returned for deletes, plan saves, deadline moves, and schedule changes. The database is modified only when the user confirms the exact action.

## Database and identity model

The site uses Manus OAuth and stores a user record keyed by the returned `openId`. The browser session cookie is named `webdev_app_session`, uses `SameSite=None; Secure`, and holds a signed app payload. All records are filtered by the authenticated user ID. New tables are created with `CREATE TABLE IF NOT EXISTS`, so restarts do not reset user data.

## Interface and design

### Explored styles

1. **Warm paper planner** (0.06): quiet editorial pages with soft cream surfaces and handwriting-adjacent detail.
2. **Clinical command center** (0.08): high-density operational panels, graphite chrome, and sharp status colors.
3. **Editorial kinetic workspace** (0.07): dark ink field, oversized typographic hierarchy, and luminous task-state accents.

### Chosen style: Editorial kinetic workspace

- **Design movement:** Contemporary editorial software—calm, capable, and deliberately unlike a generic card dashboard.
- **Core principles:** A clear now/next hierarchy; a focused content rail rather than a uniform grid; state visible at a glance; every dangerous action makes its consequence explicit.
- **Color philosophy:** Deep ink gives the workspace concentration, bone-white creates breathing room, and electric periwinkle is the ownable action color. Apricot denotes attention; jade means progress.
- **Layout paradigm:** A slim vertical navigation spine leads into a large, asymmetric work canvas. The current day anchors the left; action and analysis sit in connected editorial panels instead of repeated widgets.
- **Signature elements:** A vertical “Today” date rail, soft gradient schedule bars, and compact priority glyphs.
- **Interaction philosophy:** Primary actions use clear, one-step language. Proposed changes become review cards with an explicit confirm/cancel choice.
- **Animation:** 160–220ms opacity/translate transitions on panels and lists, respecting reduced-motion preferences. No decorative looping movement.
- **Typography:** Instrument Serif for large planning statements and Inter for UI/body content. Numerals and data use tabular figures.
- **Brand essence:** A practical AI planning partner for students and focused professionals who want credible actions, not chatbot theatre. Personality: precise, warm, composed.
- **Brand voice:** “Plan the work you can actually finish.” and “Nothing changes until you say so.”
- **Wordmark & logo:** A small route/flow glyph beside a deliberately compact `TaskFlow` wordmark.
- **Signature brand color:** `#6D5EF7` (TaskFlow periwinkle).

## Project structure

```text
client/              React UI, routes/views, API client, visual system
server/              Express app, OAuth/session middleware, SQL repository, agent/tools
public/              static route manifest
Dockerfile           production image and runtime command
```

## Deployment

A Docker image will install the pinned pnpm workspace dependencies, build the React client, and start the Express server on `PORT` (default `3000`). `/health` is public and database-aware. The project will use a server deployment with managed database persistence.
